/// <reference types="nativewind/types" />
export { };